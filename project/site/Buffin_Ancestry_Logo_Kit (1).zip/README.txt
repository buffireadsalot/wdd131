Buffin Ancestry Logo Kit
------------------------
Included:
- Logos (with 3 taglines, transparent/dark/light backgrounds)
- No-tagline versions
- Favicons and icons
- Social media headers
- Letterhead and watermark branding assets

Fonts: Raleway (Google Fonts)
Colors:
  - Gold: #C49A6C
  - Teal: #3A6F7D
  - Dark: #1C1C1C
  - Light: #FFFFFF
